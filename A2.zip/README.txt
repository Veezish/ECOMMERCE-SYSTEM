Veezish Ahmad
501080184

Class Product: (WORKS)
    - made a print stat method

Class Customer: (WORKS)
    - Mostly done for us, just made class Customer and 
      implemented the comparable interface from A1. 

Class ProductOrder: (WORKS)
    - Fully done for us. Just replaced "return false" 
      and compared two product order objects based on 
      their ordernumber from A1.

Class Book: (WORKS)
    getAuthor()     
    getYear()     
    validOptions()        
    getStockCount()      
    setStockCount()      
    reduceStockCount() 

Class ECommerceSystem: (WORKS)
    - input the products text file 
    printAllProducts()       
    printAllBooks()               
    printAllOrders()     
    printAllShippedOrders()   
    printCustomers()        
    printOrderHistory()     
    printAuthorBooks()    
    AddtoCart()         
    RemCartItem()      
    printCart()             
    orderItems()              
    orderProduct()                
    createCustomer()        
    shipOrder()                
    printAuthorBooks()       
    cancelOrder()           
    printByPrice()   
    printByName()     
    sortCustomersByName()       
    printStats()            

Class ECommerceUserInterface: (WORKS)
    - Created scanner for each method for user input.              
    - added ordershoes                                                   
    - added Author                                
    - added addtocart                                
    - added remcart               
    - added printcart      
    - added orderitems              
    - added stats                   
    - changed sortByPrice and sortByName to printbyprice and printbyname    
    - added the catch for the exception                                    

Class Shoes: (WORKS)
    - Simillar to products.
    - As pdf specifies; there's Size 6-10 in black and brown. 
    validOptions()        
    getStockCount()         
    setStockCount()          
    reduceStockCount()    

Class Cart: (WORKS)
    cartItemAdd    
    cartItemRemove  
    cartPrint      
    cartCheck      



Class CartItem: (WORKS)
    getProduct         
    getProductOptions   

Class ErrorHandling: (WORKS)
    Exceptions added:
    CustomerNFException
    CustomerNameNFException
    CustomerAddressNFException
    ProductNFException
    ProductOptionsNFException
    ProductOutOfStockException
    OrderNFException

Bonus: 
    - N/A
    
